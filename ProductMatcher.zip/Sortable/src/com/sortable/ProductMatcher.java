package com.sortable;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.ContainerFactory;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class ProductMatcher {

	/**
	 * The method that iterate through listing file and create an index
	 * @param listingFile
	 * @return index
	 * @throws IOException
	 */
	private static Map<String, HashSet<Map<String, String>>> createIndexMap( File listingFile ) throws IOException {
		
		// the initialization of the index 
		Map<String, HashSet<Map<String, String>>> _indexMap = new HashMap<String, HashSet<Map<String, String>>>();

		JSONParser parser = new JSONParser();
		ContainerFactory containerFactory = new ContainerFactory() {
			public List<String> creatArrayContainer() {
				return new LinkedList<String>();
			}

			public Map<String, String> createObjectContainer() {
				return new LinkedHashMap<String, String>();
			}

		};

		// read the listing file and create an index for quick and efficient access
		BufferedReader readerListing = new BufferedReader(new FileReader(listingFile));
		String lineListing;
		System.out.println("== Started creating index ==");
		while ((lineListing = readerListing.readLine()) != null) {

			try {
				@SuppressWarnings("unchecked")
				Map<String, String> listingMap = (Map<String, String>) parser.parse(lineListing, containerFactory);
				Iterator<Entry<String, String>> iter = listingMap.entrySet().iterator();
				while (iter.hasNext()) {
					Map.Entry<String, String> entry = (Map.Entry<String, String>) iter.next();

					if (entry.getKey().equals("manufacturer")) {

						String valueOfManufacturer = entry.getValue();

						for (String key : valueOfManufacturer.split(" ")) {

							if (_indexMap.get(key) != null) {
								HashSet<Map<String, String>> _previousValue = _indexMap.get(key);
								_previousValue.add(listingMap);
								_indexMap.put(key, _previousValue);

							} else {
								HashSet<Map<String, String>> _value = new HashSet<Map<String, String>>();
								_value.add(listingMap);
								_indexMap.put(key, _value);
							}
						}
					}

				}

			} catch (ParseException pe) {
				System.out.println(pe);
			}
		}
		System.out.println("== Finished creating index ==");

		return _indexMap;

	}

	@SuppressWarnings("unchecked")
	/**
	 * Method that iterates through the product file and 
	 * for each product finds closest matches from listing file
	 * and records in the output file
	 * @param _indexMap
	 * @param productFile
	 * @param resultFile
	 * @throws IOException
	 */
	public static void searchThroughIndexMap( Map<String, HashSet<Map<String, String>>> _indexMap,
			File productFile, File resultFile) throws IOException {

		JSONParser parser = new JSONParser();
		ContainerFactory containerFactory = new ContainerFactory() {
			public List<String> creatArrayContainer() {
				return new LinkedList<String>();
			}

			public Map<String, String> createObjectContainer() {
				return new LinkedHashMap<String, String>();
			}

		};

		FileWriter results = new FileWriter(resultFile);

		// loop through the product file and
		// for each product retrieve all the candidate listings through index
		// and compare product with each candidate listing
		// and create a list of closest matches
		BufferedReader readerProduct = new BufferedReader(new FileReader(productFile));
		String lineProduct;

		System.out.println("== Iterating throught products to find matches with listing ==");
		
		while ((lineProduct = readerProduct.readLine()) != null) {

			try {
				Map<String, String> productMap = (Map<String, String>) parser.parse(lineProduct, containerFactory);

				JSONObject result = new JSONObject();
				JSONArray listingArray = new JSONArray();

				if (_indexMap.get(productMap.get("manufacturer")) != null) {
					// retrieve candidates from index
					HashSet<Map<String, String>> _candidates = _indexMap.get(productMap.get("manufacturer"));

					// main matching algorithm
					// iterate through candidate and match against product
					Iterator<Map<String, String>> iter = _candidates.iterator();
					while (iter.hasNext()) {
						Map<String, String> _candidate = iter.next();
						Iterator<Entry<String, String>> it = _candidate.entrySet().iterator();
						while (it.hasNext()) {
							Map.Entry<String, String> pairs = (Map.Entry<String, String>) it.next();

							if (pairs.getKey().equals("title")) {
								String description = pairs.getValue();

								if (description.toLowerCase().contains(productMap.get("manufacturer").toLowerCase())
										&& description.toLowerCase().contains(productMap.get("model").toLowerCase())) {
									if (productMap.containsKey("family")) {
										// if family exists it must match
										if (description.toLowerCase().contains(productMap.get("family").toLowerCase()))
											listingArray.add(_candidate);

									} else {
										// found a match without family
										listingArray.add(_candidate);
									}

								}

							}

						}

					}
					
					result.put("listings", listingArray);
					result.put("product_name", productMap.get("product_name"));

					results.write(JSONValue.toJSONString(result));
					results.write("\n");
				}
			}

			catch (ParseException pe) {
				System.out.println(pe);
			}
		}

		System.out.println("== Completed ==");

	}

	/**
	 * Main method for product matcher program 
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {

		if (args.length != 3) {
			System.out.println("USAGE: java ProductMacher listingFileName productFileName resultFileName \n"
							+ "e.g. java ProductMacher resources/listings.txt resources/products.txt resources/results.txt");
			return;
		}

		String listing = args[0];
		String products = args[1];
		String results = args[2];

		/*
		 String listing = "resources/listings.txt"; 
		 String products ="resources/products.txt"; 
		 String results = "resources/results.txt";
		 */

		File listingFile = new File(listing);
		File productFile = new File(products);
		File resultFile = new File(results);

		Map<String, HashSet<Map<String, String>>> _indexByManufacturer = createIndexMap(listingFile);

		searchThroughIndexMap(_indexByManufacturer, productFile, resultFile);

	}

}
